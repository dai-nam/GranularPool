CMOS digital logic emulation objects
===

This is a collection of small objects that emulate
logic CMOS components.
The emulation assumes idealized components.
