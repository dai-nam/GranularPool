subdir
======

pd-lib-builder project that shows how to compile
a library that contains a single C-file in a separate src/ directory,
that is compiled into a single binary containing a subdir Pd-objectclass.

this is a special case of the one-object-per-binary library structure.
