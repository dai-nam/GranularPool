multishared
===========

minimal pd-lib-builder project that shows how to compile
a library that contains multiple C-files that are compiled into
multiple binaries each containing a different Pd-objectclass.
a local shared library is used for common components.

this is an extended case of the one-object-per-binary library structure.
